﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.ComponentModel;
using System.Threading.Tasks;
using Cloo;
using System.IO;
using System.Windows.Forms;
using System.Drawing;
using System.Drawing.Drawing2D;

// TODO: Must add read from file, banchmark and carry out on GPU
namespace testOpenCL
{
    internal class Program
    {
        #region opencl code
        private const String Source = @"
#pragma OPENCL EXTENSION cl_khr_global_int32_base_atomics : enable

void GetSemaphor(global int* semaphor)
{
    int occupied = atom_xchg(semaphor, 1);
    while (occupied > 0) {
        occupied = atom_xchg(semaphor, 1);
    }
}

void ReleaseSemaphor(global int* semaphor)
{
    int prevVal = atom_xchg(semaphor, 0);
}

kernel void FindMaxABS(constant float* a, 
                         global float* m, 
                         global int* posMax, 
                         global int* semaphor)
{
    int pos = get_global_id(0);
    int sz = get_global_size(0);
    int col = 0;
    int raw = pos * sz;
    float _max = -1;
    for (int i = 0; i < sz; ++i) {
        if (i == pos) continue;
        if (_max < fabs(a[raw + i])) {
            _max = fabs(a[raw + i]);
            col = i;
        }
    }

    GetSemaphor(semaphor);
    if (*m < _max) {
        *m = _max;
        posMax[0] = pos;
        posMax[1] = col;
    }
    ReleaseSemaphor(semaphor);
}

kernel void MultMatrix(constant float* a, constant float* b, global float* res)
{
    int sz = get_global_size(0);
    int raw = get_global_id(0);
    int col = get_global_id(1);
    raw *= sz;
    float sum = 0;
    for (int i = 0; i < sz; ++i) {
        sum += a[raw + i] * b[col + i * sz];
    }
    res[raw + col] = sum;
}

kernel void ComputeNorm(constant float* a,
                        global float* res,
                        global int* semaphor)
{
    int sz = get_global_size(0);
    int pos = get_global_id(0);
    int raw = pos * sz;
    float sum = 0;
    for (int i = 0; i < sz; ++i) {
        if (pos == i) continue;
        sum += a[raw + i] * a[raw + i];
    }
    GetSemaphor(semaphor);
    *res += sum;
    ReleaseSemaphor(semaphor);
}

kernel void TransposeMatrix(constant float* a,
                            global float* res)
{
    int pos = get_global_id(0);
    int sz = get_global_size(0);
    int raw = pos * sz;
    for (int i = 0; i < sz; ++i) {
        res[pos + i * sz] = a[raw + i]; 
    }
}";
        #endregion
        const String SeparatorStr = "*************************************";
        private static void Main(String[] args)
        {
            Banchmark();
            //RotateMethdAsync(3);
            //RotateMethod(2);
            //Console.ReadLine();
        }
        private static Tuple<ComputePlatform, ComputeDevice> FindAMDPLatform()
        {
            Int64 _min = Int64.MaxValue;
            ComputePlatform resPL = null;
            ComputeDevice resDEV = null;

            foreach (var pl in ComputePlatform.Platforms)
            {
                foreach (var dev in pl.Devices)
                {
                    if (_min > dev.MaxClockFrequency * dev.MaxComputeUnits)
                    {
                        resPL = pl;
                        resDEV = dev;
                        _min = dev.MaxClockFrequency * dev.MaxComputeUnits;
                    }
                }
            }
            return new Tuple<ComputePlatform, ComputeDevice>(resPL, resDEV);
        }

        public static void RotateMethdAsync(Int32 count)
        {
            var platform = ComputePlatform.Platforms[2];
            var device = platform.Devices[0];
            var properties = new ComputeContextPropertyList(platform);
            var context = new ComputeContext(ComputeDeviceTypes.All, properties, null, IntPtr.Zero);
            var queue = new ComputeCommandQueue(context, device, ComputeCommandQueueFlags.None);
            var prog = new ComputeProgram(context, Source);
            prog.Build(context.Devices, "", null, IntPtr.Zero);
            var idKernelFindMaxAbs  = prog.CreateKernel("FindMaxABS");
            var idKernelMultMatrix  = prog.CreateKernel("MultMatrix");
            var idKernelComputeNorm = prog.CreateKernel("ComputeNorm");
            var idKernelTranspose   = prog.CreateKernel("TransposeMatrix");
            var startTime = DateTime.Now;
            var matrixA = new Single[count * count];
            var matrixB = new Single[count * count];
            var matrixC = new Single[count * count];
            #region init matrix
            matrixA = new Single[] { 4, 2, 1, 2, 5, 3, 1, 3, 6 };
            #endregion    
            var EPS = (Single)0.3;
            var EPSk = Off(matrixA, count, idKernelComputeNorm, queue, context);
            var LogFile = new StreamWriter("RotateMethodAsync.log", false, Encoding.Unicode);
            
            while (EPSk >= EPS)
            {
                Tuple<Int32, Int32> posMax = new Tuple<Int32, Int32>(0, 0);
                #region init rotateMatrix
                var matrixRotate = new Single[count * count];
                for (int k = 0; k < count; ++k)
                    matrixRotate[k * count + k] = 1;
                #endregion
                #region find absolute max element
                {
                    var seamphor = new Int32[] { 0 };
                    var pos = new Int32[] { 0, 0 };
                    var maxElem = new Single[] { -1 };

                    var bufMatrixA = new ComputeBuffer<Single>(context,
                                                            ComputeMemoryFlags.ReadOnly | ComputeMemoryFlags.UseHostPointer,
                                                            matrixA);
                    var bufMaxElem = new ComputeBuffer<Single>(context,
                                                            ComputeMemoryFlags.ReadWrite | ComputeMemoryFlags.UseHostPointer,
                                                            maxElem);
                    var bufSemaphor = new ComputeBuffer<Int32>(context,
                                                            ComputeMemoryFlags.ReadWrite | ComputeMemoryFlags.UseHostPointer,
                                                            seamphor);
                    var bufPos = new ComputeBuffer<Int32>(context,
                                                            ComputeMemoryFlags.WriteOnly | ComputeMemoryFlags.UseHostPointer,
                                                            pos);


                    queue.WriteToBuffer(matrixA, bufMatrixA, false, null);
                    queue.WriteToBuffer(maxElem, bufMaxElem, false, null);
                    queue.WriteToBuffer(seamphor, bufSemaphor, false, null);

                    idKernelFindMaxAbs.SetMemoryArgument(0, bufMatrixA);
                    idKernelFindMaxAbs.SetMemoryArgument(1, bufMaxElem);
                    idKernelFindMaxAbs.SetMemoryArgument(2, bufPos);
                    idKernelFindMaxAbs.SetMemoryArgument(3, bufSemaphor);

                    queue.Execute(idKernelFindMaxAbs, null, new Int64[] { (Int64)count }, null, null);
                    queue.Finish();
                    queue.ReadFromBuffer(bufPos, ref pos, false, null);

                    posMax = new Tuple<Int32, Int32>(pos[0], pos[1]);
                }
                #endregion
                #region set angel for matrix of rotates
                Int32 i = posMax.Item1;
                Int32 j = posMax.Item2;
                LogFile.WriteLine(String.Format("position of max: ({0};{1})", i + 1, j + 1));
                Single angel = (Single)(Math.Abs(matrixA[i * count + i] - matrixA[j * count + j])
                    < EPS ? Math.PI / 4 :
                    (0.5 * Math.Atan(2.0 * matrixA[i * count + j]
                                    / (matrixA[i * count + i] - matrixA[j * count + j]))));
                LogFile.WriteLine(String.Format("angel = {0}", angel));
                matrixRotate[i * count + i] = matrixRotate[j * count + j] =
                    (Single)Math.Cos(angel);
                matrixRotate[i * count + j] = -(matrixRotate[j * count + i] =
                    (Single)Math.Sin(angel));
                #endregion
                #region transpose rotate matrix
                var matrixRotateTransposed = new Single[count * count];

                var buffMatrixA = new ComputeBuffer<Single>(context,
                                                        ComputeMemoryFlags.ReadOnly | ComputeMemoryFlags.UseHostPointer,
                                                        matrixRotate);
                var buffMatrixB = new ComputeBuffer<Single>(context,
                                                        ComputeMemoryFlags.WriteOnly | ComputeMemoryFlags.UseHostPointer,
                                                        matrixRotateTransposed);

                queue.WriteToBuffer(matrixRotate, buffMatrixA, false, null);

                idKernelTranspose.SetMemoryArgument(0, buffMatrixA);
                idKernelTranspose.SetMemoryArgument(1, buffMatrixB);

                queue.Execute(idKernelTranspose, null, new Int64[] { (Int64)count }, null, null);
                queue.Finish();
                queue.ReadFromBuffer(buffMatrixB, ref matrixRotateTransposed, false, null);
                #endregion
                #region multiply of matrix
                {
                    var bufMatrixA = new ComputeBuffer<Single>(context,
                                                            ComputeMemoryFlags.ReadOnly | ComputeMemoryFlags.UseHostPointer,
                                                            matrixRotateTransposed);
                    var bufMatrixB = new ComputeBuffer<Single>(context,
                                                            ComputeMemoryFlags.ReadOnly | ComputeMemoryFlags.UseHostPointer,
                                                            matrixA);
                    var bufMatrixC = new ComputeBuffer<Single>(context,
                                                            ComputeMemoryFlags.WriteOnly | ComputeMemoryFlags.UseHostPointer,
                                                            matrixC);

                    queue.WriteToBuffer(matrixRotateTransposed, bufMatrixA, false, null);
                    queue.WriteToBuffer(matrixA, bufMatrixB, false, null);

                    idKernelMultMatrix.SetMemoryArgument(0, bufMatrixA);
                    idKernelMultMatrix.SetMemoryArgument(1, bufMatrixB);
                    idKernelMultMatrix.SetMemoryArgument(2, bufMatrixC);

                    queue.Execute(idKernelMultMatrix, null, new Int64[] { (Int64)count, (Int64)count }, null, null);
                    queue.Finish();
                    queue.ReadFromBuffer(bufMatrixC, ref matrixC, false, null);

                    bufMatrixA = new ComputeBuffer<Single>(context,
                                                        ComputeMemoryFlags.ReadOnly | ComputeMemoryFlags.UseHostPointer,
                                                        matrixC);
                    bufMatrixB = new ComputeBuffer<Single>(context,
                                                        ComputeMemoryFlags.ReadOnly | ComputeMemoryFlags.UseHostPointer,
                                                        matrixRotate);
                    bufMatrixC = new ComputeBuffer<Single>(context,
                                                        ComputeMemoryFlags.WriteOnly | ComputeMemoryFlags.UseHostPointer,
                                                        matrixA);

                    queue.WriteToBuffer(matrixC, bufMatrixA, false, null);
                    queue.WriteToBuffer(matrixRotate, bufMatrixB, false, null);

                    idKernelMultMatrix.SetMemoryArgument(0, bufMatrixA);
                    idKernelMultMatrix.SetMemoryArgument(1, bufMatrixB);
                    idKernelMultMatrix.SetMemoryArgument(2, bufMatrixC);

                    queue.Execute(idKernelMultMatrix, null, new Int64[] { (Int64)count, (Int64)count }, null, null);
                    queue.Finish();
                    queue.ReadFromBuffer(bufMatrixC, ref matrixA, false, null);
                }
                #endregion
                EPSk = Off(matrixA, count, idKernelComputeNorm, queue, context);
                #region print matrix
                LogFile.WriteLine(String.Format("Matrix Rotate:"));
                for (int k = 0; k < count; ++k)
                {
                    for (int u = 0; u < count; ++u)
                    {
                        //Console.Write(String.Format("{0} ", matrixA[i * count + j]));
                        LogFile.Write(String.Format("{0} ", matrixRotate[k * count + u]));
                    }
                    //Console.WriteLine();
                    LogFile.WriteLine();
                }
                LogFile.WriteLine(String.Format("Matrix A:"));
                for (int k = 0; k < count; ++k)
                {
                    for (int u = 0; u < count; ++u)
                    {
                        //Console.Write(String.Format("{0} ", matrixA[i * count + j]));
                        LogFile.Write(String.Format("{0} ", matrixA[k * count + u]));
                    }
                    //Console.WriteLine();
                    LogFile.WriteLine();
                }
                #endregion
                LogFile.WriteLine(String.Format("EPS = {0} || EPS_k = {1}", EPS, EPSk));
                LogFile.WriteLine(SeparatorStr);
            }      
              
            var endTime = DateTime.Now;
            Console.WriteLine(String.Format("time async: {0}", (endTime - startTime).TotalMilliseconds));
            LogFile.Close();
        }

        public static void RotateMethod(Int32 count)
        {
            var startTime = DateTime.Now;
            var matrixA = new Single[count * count];
            var matrixRotate = new Single[count * count];


            for (int i = 0; i < count; ++i)
            {
                matrixRotate[i * count + i] = 1;
                for (int j = 0; j < count; ++j)
                {
                    matrixA[i * count + j] = i * count + j + 1;
                }
            }

            Tuple<Int32, Int32> posMax = new Tuple<Int32, Int32>(0, 0);
            var _max = (Single)Math.Abs(matrixA[posMax.Item1 * count + posMax.Item2]);
            
            for (int i = 0; i < count; ++i)
            {
                for (int j = 0; j < count; ++j)
                {
                    if (_max < (Single)Math.Abs(matrixA[i * count + j]))
                    {
                        _max = (Single)Math.Abs(matrixA[i * count + j]);
                        posMax = new Tuple<Int32, Int32>(i, j);
                    }
                }
            }
            Single angel = (Single)(Math.Abs(matrixA[posMax.Item1 * count + posMax.Item1] - matrixA[posMax.Item2 * count + posMax.Item2])
                < Double.Epsilon ? Math.PI / 4 :
                (0.5 * Math.Atan(2.0 * matrixA[posMax.Item1 * count + posMax.Item2])
                                / (matrixA[posMax.Item1 * count + posMax.Item1] - matrixA[posMax.Item2 * count + posMax.Item2])));
            matrixRotate[posMax.Item1 * count + posMax.Item1] = matrixRotate[posMax.Item2 * count + posMax.Item2] =
                (Single)Math.Cos(angel);
            matrixRotate[posMax.Item1 * count + posMax.Item2] = -(matrixRotate[posMax.Item2 * count + posMax.Item1] =
                (Single)Math.Sin(angel));

            var tempMatrix = new Single[count * count];
            for (int i = 0; i < count; ++i)
            {
                for (int j = 0; j < count; ++j)
                {
                    Single sum = 0;
                    for (int k = 0; k < count; ++k)
                    {
                        sum += matrixRotate[i * count + k] * matrixA[j + k * count];
                    }
                    tempMatrix[i * count + j] = sum;
                }
            }
            for (int i = 0; i < count; ++i)
            {
                for (int j = 0; j < count; ++j)
                {
                    Single sum = 0;
                    for (int k = 0; k < count; ++k)
                    {
                        sum += tempMatrix[i * count + k] * matrixRotate[j + k * count];
                    }
                    matrixA[i * count + j] = sum;
                }
            }
            var endTime = DateTime.Now;
            Console.WriteLine("time sync: {0}", (endTime - startTime).TotalMilliseconds);
        }

        #region calculate norm of matrix
        public static Single Off(Single[] arr, 
                                Int32 sz,
                                ComputeKernel kernel, 
                                ComputeCommandQueue queue, 
                                ComputeContext context)
        {
            var semaphor = new Int32[] { 0 };
            var res = new Single[] { 0 };
            var bufMatrixA = new ComputeBuffer<Single>(context,
                                                    ComputeMemoryFlags.ReadOnly | ComputeMemoryFlags.UseHostPointer,
                                                    arr);
            var bufNorm = new ComputeBuffer<Single>(context,
                                                    ComputeMemoryFlags.WriteOnly | ComputeMemoryFlags.UseHostPointer,
                                                    res);
            var bufSemaphor = new ComputeBuffer<Int32>(context,
                                                    ComputeMemoryFlags.ReadWrite | ComputeMemoryFlags.UseHostPointer,
                                                    semaphor);

            kernel.SetMemoryArgument(0, bufMatrixA);
            kernel.SetMemoryArgument(1, bufNorm);
            kernel.SetMemoryArgument(2, bufSemaphor);

            queue.Execute(kernel, null, new Int64[] { (Int64)sz }, null, null);

            queue.ReadFromBuffer(bufNorm, ref res, true, null);
            return (Single)Math.Sqrt(res[0]);
        }
        #endregion

        public static void Banchmark()
        {
            Single W = 640, H = 480;
            using (var bmp = new Bitmap((Int32)W, (Int32)H))
            {
                using (var graph = Graphics.FromImage(bmp))
                {
                    String drawNameX = "Size";
                    String drawNameY = "Time";
                    var drawFont = new Font("Arial", 14);
                    var drawBrush = new SolidBrush(Color.Red);
                    Single posxNameX = W / 10 + 400;
                    Single posyNameX = 8 * H / 10 + 50;
                    Single posxNameY = W / 10 - 50;                    
                    Single posyNameY = 8 * H / 10 - 250;
                    graph.DrawString(drawNameX, drawFont, drawBrush, posxNameX, posyNameX);
                    graph.DrawString(drawNameY, drawFont, drawBrush, posxNameY, posyNameY);
                    Pen bluePen = new Pen(Color.Blue, 3);
                    var X = new Int32[100];
                    var Y = new Int32[100];
                    for (int i = 0; i < 100; ++i)
                        X[i] = Y[i] = i;
                    for (int i = 0; i < 99; i++)
                    {
                        graph.DrawLine(bluePen, W / 4 + X[i], 2 * H / 3 - Y[i], W / 4 + X[i + 1], 2 * H / 3 - Y[i + 1]);
                    }
                    var path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), "Example.png");
                    bmp.Save(path);
                }
            }
        }
    }



        //class DrawTest : Form
        //{
        //    public DrawTest() : base()
        //    {
        //        this.TopMost = true;
        //        this.DoubleBuffered = true;
        //        this.ShowInTaskbar = true;
        //        this.FormBorderStyle = FormBorderStyle.None;
        //        this.WindowState = FormWindowState.Maximized;
        //        this.BackColor = Color.Black;
        //        this.TransparencyKey = Color.Red;
        //    }
        //    protected override void OnPaint(PaintEventArgs e)
        //    {
        //        e.Graphics.DrawRectangle(Pens.Blue, 0, 0, 200, 200);
        //        this.Invalidate();
        //    }
        //}
}
